<?
function despeckleImage($imagePath)
{
    $imagick = new \Imagick(realpath($imagePath));
    $imagick->despeckleImage();
    header("Content-Type: image/jpg");
    echo $imagick->getImageBlob();
} 
despeckleImage('bir2.png');