<?
include "top.php";





$ssq = $db->query("SELECT * FROM mainblog1");
while($pr = $ssq->fetchArray(SQLITE3_ASSOC) ) { 
$title = $pr['title'];
echo "$title<br>"; } 

?>