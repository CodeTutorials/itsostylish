<?php
require "config.php";
$sq = $db->query("ALTER TABLE cust1 ADD cust_tok_valid");
?>
cust_valid, cust_tok