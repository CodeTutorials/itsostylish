<?php
// Display all sqlite tables
    require "config.php";
    $tablesquery = $db->query("SELECT name FROM sqlite_master WHERE type='table';");

    while ($table = $tablesquery->fetchArray(SQLITE3_ASSOC)) {
        if ($table['name'] != "sqlite_sequence") {
            echo "<a href='viewtable.php?table=$table[name]'>" . $table['name'] . "</a><br />";
        }
    } 
    


    
?>