<?php
require "../confsew.php";
?>
