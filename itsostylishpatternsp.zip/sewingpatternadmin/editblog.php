<?php
$id = $_REQUEST['id'];
echo "$id";
require "config.php";
$sqlpp = $db->query("SELECT * FROM bodblog WHERE bbl_id = '$id'");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<form action='processb.php' enctype='multipart/form-data' method='post'>";
echo "<label>Subtitle</label><br>";
echo "<input type='text' name='subtitle' value='$ro[subtitle]' />";
echo "<label>Description</label><br>";
echo "<textarea rows='30' cols='40' name='txt'>$ro[txt]</textarea><br>";
echo "<label>Equipment</label><br>";
echo "<textarea rows='30' cols='40' name='equip'>$ro[txt]</textarea><br>";
echo "<select name='details'>
<option value='lis'>List</option>
<option value='para'>Paragraph</option>
</select><br>";
echo "<input type='text' name='titleid' value='$ro[titleid]' />";
echo "<input type='text' name='newid' value='$id' />";
echo "<label>Image</label><br><input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file' id='userfile' />
           <br>
<input type='submit' name='submit' value='submit' /></form>"; } 
?>
titleid'];
$subtitle = cl($_POST['subtitle']);
$txt = cl($_POST['txt']);
$equip = $_POST['equip'];
$details = $_POST['details'];
bodblog(titleid, subtitle, txt, equip, details, img1) values('$titleid', '$subtitle', '$txt', '$equip', '$details', '$image')