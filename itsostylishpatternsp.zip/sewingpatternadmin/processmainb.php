<?php
require "config.php";
require "../functions/bootlib.php";
$title = cl($_POST['title']);
$link = $_POST['link'];
$descps = cl($_POST['descps']);
$byline = $_POST['byline'];
$video = $_POST['video'];
$cate1 = $_POST['cate1'];
$cate2 = $_POST['cate2'];
$cate3 = $_POST['cate3'];
echo "title $title link $link descps $descps byline $byline video $video cate $cate1 cate $cate2 cate $cate3<br>";


$fill = strtolower($_FILES['userfile'] ['name']);
$fil = substr($fil1, -3); 
$filj = substr(fill, -4);
$tmpName = $_FILES['userfile'] ['tmp_name'];
$imagearray = getimagesize($tmpName);

echo "mime $imagearray[mime] <br>";
$valid_types = array(IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG);

echo "file $fill sub $fil";







if (in_array($imagearray[2],  $valid_types)) { 

echo $_FILES['userfile'] ['tmp_name'];
$fileName = $_FILES['userfile'] ['name'];
$tmpName = $_FILES['userfile'] ['tmp_name'];
$fileSize = $_FILES['userfile'] ['size'];
echo "size $fileSize<br>";
$fp = fopen($tmpName, 'r');
$content = fread($fp, $fileSize);
$content = addslashes($content);
fclose($fp);
$picture = str_replace(' ', '_', $tmpName);

$source = $picture;
$sttitle = str_replace(' ', '-', $title);
$sqw = $db->query("SELECT * FROM mainblog1 ORDER BY bl_id DESC LIMIT 1");
while($ro = $sqw->fetchArray(SQLITE3_ASSOC ) ) { 
$pid = $ro['id']; } 
$rpid = $pid + 1;
$na = $sttitle . '-' .  $rpid;
$target = '../sew/' . $fileName;
$newname = '../sew/' . $na . '.jpg';
$newna = 'sew/' . $na . '.jpg';
move_uploaded_file($source, $newname );
$newname = 'sew/' . $na . '.jpg';

$image = $newname;
echo "File<b> $fileName $picture picture</b> uploaded as id= $id<br>";
echo "File<b> $fileName</b> uploaded<br>"; 
echo "<b>All images in pic directory gallery</b></br >"; } else { 
echo "the type of file is not acceptable, go back and try again";  } 



echo "File<b> $fileName</b> uploaded<br>";
echo "<b>All images in pic directory gallery</b></br >"; 
$date = date("Y-m-d");

$sq = $db->query("INSERT INTO mainblog1(title, date, link, video, byline, descps, img, cate1, cate2, cate3) values('$title', '$date', '$link', '$video', '$byline', '$descps', '$image', '$cate1', '$cate2', '$cate3')");

?>


