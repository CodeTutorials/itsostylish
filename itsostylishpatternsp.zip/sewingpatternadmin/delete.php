<?
require "config.php";
$sq = $db->query("DELETE FROM bodblog WHERE bbl_id = '30'");