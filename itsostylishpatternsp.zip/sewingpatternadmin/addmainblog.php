
<?php
require "config.php";
?>
<h2>Add Main Blog</h2>
<form action='processmainb.php' enctype='multipart/form-data' method='post'>
<label>Title</label><br>
<input type='text' name='title' /><br>
<label>Instruction Link</label><br>
<input type='text' name='link' /><br>
<label>Byline</label><br>
<input type='text' name='byline' /><br>
<label>Description</label><br>
<textarea name='descps'rows='30' cols='30'></textarea><br>
<label>Video</label><br>
<input type='text' name='video' /></br>
<label>Cate 1</label></br>
<select name='cate1'>
<?php
$sqlpp = $db->query("SELECT * FROM cate");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<option value='$ro[id]'>$ro[cate_title]</option>"; } 
?>
</select><br>
<label>Cate 2</label></br>
<select name='cate2'>
<?php
$sqlpp = $db->query("SELECT * FROM cate");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<option value='$ro[id]'>$ro[cate_title]</option>"; } 
?>
</select><br>
<label>Cate 3</label></br>
<select name='cate3'>
<?php
$sqlpp = $db->query("SELECT * FROM cate");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<option value='$ro[id]'>$ro[cate_title]</option>"; } 
?>
</select><br>
<label>Image</label><br><input type='hidden' name='MAX_FILE_SIZE' value='30000000' /><input name='userfile' type='file' id='userfile' />
           <br>
<input type='submit' name='submit' value='submit' /></form>

