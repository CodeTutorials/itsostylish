<?php
require "config.php";
$id = $_REQUEST['id'];
$sqlpp = $db->query("SELECT * FROM bodblog WHERE titleid = '$id'");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 

echo "<a href='editblog.php?id=$ro[bbl_id]'>edit $ro[bbl_id] $ro[subtitle]</a></br>";

} 
?>