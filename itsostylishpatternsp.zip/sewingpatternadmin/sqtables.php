<a href='viewtable.php?table=mainblog1'>mainb</a><br>
<a href='viewtable.php?table=bodblog'>bodblog</a>
<a href='viewtable.php?table=cate'>Cate</a>
bodblog
cate