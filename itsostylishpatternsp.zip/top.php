<?php
session_start();

require "functions/bootlib.php";
require "config.php";
?>