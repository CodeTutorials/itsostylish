<?
include "config.php";
 $tbname = $_REQUEST['table'];   
$sq = $db->query("SELECT sql FROM sqlite_master
WHERE tbl_name = '$tbname' AND type = 'table'");
while($field = $sq->fetchArray(SQLITE3_NUM) ) { 
echo "$field[0]<br>";
$newtxt = str_replace("CREATE TABLE", '', $field[0]);
$newtxt1 = str_replace("INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT", '', $newtxt);
$newtxt2 = str_replace("$tbname", '', $newtxt1);
$newtxt3 = str_replace('(', '', $newtxt2);
$newtxt4 = str_replace(')', '', $newtxt3);

$tbarray = explode(',', $newtxt4);

$sql = $db->query("SELECT * FROM $tbname");
while ($row = $sql->fetchArray(SQLITE3_ASSOC)) { 
echo "<table border='1'><tr>";
foreach($tbarray as $tb) { 
$ws = trim($tb);

echo "<td><span><b>$ws </b></span><td>";
echo "<td><span> $row[$ws] </span><td>";


} 


echo "<tr></table><br><hr>"; } }