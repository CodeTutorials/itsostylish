<?php
include "top.php";
require "header.php";
?>
<div class='container-fluid'>

<div class='row'>
<div style='margin-top:2em;' class='col-12 text-center'><h2>Itsostylish Sewing Patterns</h2><p>Totally free patterns and sewing tutorials online. Free for commercial use see terms for restrictions.</p>
</div>
</div>
<div class='row>
<div class='col-12 text-center'><h2>How to print out your digital pattern</h2><p>Download the PDFs there are usually two or more, each PDF is titled.
   You can print out the full pattern sheets if you have access to a printer, such a
a Canon large format printer. Set this printer to print out actual size. Print only
the pages in your required size.
   You can print out the pattern on a home printer in A4(letter size) sections, and
stick them together.
   Use Adobe Reader or Acrobat to format your print. This is free software from Adobe
and can be used in any computer. Use ““Print Set Up” to format. Set to “Poster”,
tick “Tile”, tick “Add Cut Marks” overlap 0.5cm. Set paper size to A4.
   Print only the required size, if sizes are printed onto one sheet all lines are
colour coded for easy reference and cutting. Your printer will print all necessary
sections with cut marks on each numbered sheet so that you can easily stick sections
together.
   Print out the pattern make-up instuctions and read them first, before starting
your project.</p>
<?
require "footer.php";
?>
</div>
<?
require "bootstrapbottom.php";
?>