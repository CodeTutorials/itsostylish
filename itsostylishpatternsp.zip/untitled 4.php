<?
require "top.php";
$sqlpp = $db->query("SELECT * FROM mainblog1");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "id $ro[bl_id] $ro[title]</br>"; 
echo "$ro[link] <br> $ro[video]</br>"; 



echo "<table role='presentation' border='0' cellpadding='0' cellspacing='0' width='100%'>
		            		<tr>
                      <td valign='top' width='50%' style='padding-top: 20px;'>
                        <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='100%'>
                          <tr>
                            <td style='padding-right: 10px;'>
                              <img src='$ro[img]' alt='' style='width: 100%; max-width: 600px; height: auto; margin: auto; display: block;'>
                            </td>
                          </tr>
                          <tr>
                            <td class='text-services' style='text-align: left;'>
                            	<h3> $ro[title]</h3>
                             	<p>$ro[descps]</p>
                             	<p><a href='#' class='btn btn-primary'>Read more</a></p>
                            </td>
                          </tr>
                        </table>
                      </td>"; } 
                      ?>