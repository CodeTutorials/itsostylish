<?php
require "functions/bootlib.php";
require "config.php";
$sq = $db->query("SELECT * FROM cust1");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$name = cr($stp, $row['cust_name'], $action = 'inv');
$email = cr($stp, $row['cust_em'], $action = 'inv');
echo "name $name<br>";
echo "email $email<br>";
echo "$row[cust_download]<br>";
echo "newsletter $row[cust_nl]<br>";
echo "valid $row[cust_valid]<br><hr>";
} 
