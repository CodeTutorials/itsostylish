<?
require "top.php";
require "header.php";

?>
<div class='container-fluid'>
<div class='row'>
<div class='col-12'>
<?
$ema = ($_REQUEST['em']);

$wr = urldecode($ema);
$nl = cr($stp, $wr, $action = 'inv');

$sq = $db->query($conn, "SELECT * FROM cust1 WHERE cust_em = '$ema'");
while($row = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$emm = $row[cust_em]; 
echo "$emm"; } 
if($emm != $nl) { 
echo "we do not have this address in our database, please send a valid address"; } 
elseif ($emm === $nl) {


while($rowx = $sq->fetchArray(SQLITE3_ASSOC) ) { 
$emm = $rowx['cust_em'];
$id = $rowx['cust_id'];
$status = $rowx['cust_valid'];
 } 
 
 
 $sqa = $db->query("UPDATE cust1 SET cust_valid = '1' WHERE cust_id = '$id'");
 
 echo "Your email address has been removed from our newsletter listing";
 
 } 
 ?>
</div></div>
</div>