<?
require "config.php";
$sq = $db->query("DELETE FROM cust1");