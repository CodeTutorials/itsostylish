<?
$tok = '1,2,3,4,5,6,7,8,a,b,d,9,c,h,b,v,y,r';
$tokarray = explode(',', $tok);

shuffle($tokarray);

$tokval = $tokarray[1] . $tokarray[4] . $tokarray[0] . $tokarray[6] . $tokarray[8]. $tokarray[7];
$tim = time();
$fintok = $tokval . $tim;
echo "$fintok";
