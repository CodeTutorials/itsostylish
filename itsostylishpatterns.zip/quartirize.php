<?
function quantizeImage($imagePath, $numberColors, $colorSpace, $treeDepth, $dither)
{
    $imagick = new \Imagick(realpath($imagePath));
    $imagick->quantizeImage($numberColors, $colorSpace, $treeDepth, $dither, false);
    $imagick->setImageFormat('png');
    header("Content-Type: image/png");
    echo $imagick->getImageBlob();
} 
$imagePath = "dogz.png";
$numberColors = "22";
$colorSpacd = "RGB";
$dither = "false";
quantizeImage($imagePath, $numberColors, $colorSpace, $treeDepth, $dither);