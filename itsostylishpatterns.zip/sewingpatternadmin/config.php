<?
require "../confsew.php";
?>
