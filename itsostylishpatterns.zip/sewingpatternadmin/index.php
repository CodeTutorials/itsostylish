<?
require "config.php";

$sqlpp = $db->query("SELECT * FROM mainblog1");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
$title = $ro['title'];
$link = $ro['link'];
$descps = $ro['descps'];
$byline = $ro['byline'];
$video = $ro['video'];
$cate1 = $ro['cate1'];
$cate2 = $ro['cate2'];
$cate3 = $ro['cate3'];
echo "$title $ro[bl_id]<br>";
} 
?>