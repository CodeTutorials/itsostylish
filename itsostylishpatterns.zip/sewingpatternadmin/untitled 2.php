1 How to make a mermaid skirt. Free pattern
mermaidskirtinstruction.pdf 
https://www.youtube.com/embed/V8fD7fLCPGM
Itsostylish 
Sew a mermaid skirt. Follow our easy to understand tutorial with video and written instruction. Free multi-sized sewing pattern.
pic/f1581332232.jpg
2 How to sew a Lace up front sundress
laceupdress.pdf 
https://www.youtube.com/embed/hJy0cb6UIhY
Itsostylish 
Make a sundress with a lace up front. Follow our easy to understand tutorial with video and written instruction. Instructions are on this blog posting as well as a handy PDF download at the link below. Free multi-sized PDF sewing pattern. Sizes 30 - 40i inch in British metric sizing, adjust for your country - American sizing would mean that the smallest size is a size 1