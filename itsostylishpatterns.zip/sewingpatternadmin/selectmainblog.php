<?
require "config.php";
$sqlpp = $db->query("SELECT * FROM mainblog1");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "id $ro[bl_id] $ro[title]</br>"; 
echo "$ro[link] <br> $ro[video]</br>"; 
echo "$ro[byline] <br> $ro[descps]</br>"; 
echo "<img src='../../../pic/$ro[img]' />$ro[img]</br>"; 


} 