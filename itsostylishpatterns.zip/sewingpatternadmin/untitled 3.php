<?
include "config.php";
$sq = $db->query("DELETE FROM mainblog1 WHERE bl_id = '8'");