<?
require "config.php";
$sqlpp = $db->query("SELECT * FROM mainblog1");
while($ro = $sqlpp->fetchArray(SQLITE3_ASSOC ) ) { 
echo "<a href='addtoblog.php?id=$ro[bl_id]'>$ro[title]</a></br>"; 
echo "<a href='editbloglead.php?id=$ro[bl_id]'>edit $ro[title]</a></br>";

} 
?>