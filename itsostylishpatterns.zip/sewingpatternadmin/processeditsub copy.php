<?
require "config.php";
require "../../../libsql.php";
$newid = $_REQUEST['newid'];
$titleid = $_POST['titleid'];
$subtitle = cl($_POST['subtitle']);
$txt = cl($_POST['txt']);
$equip = $_POST['equip'];
$details = $_POST['details'];

$fill = strtolower($_FILES['userfile'] ['name']);
$fil = substr($fil1, -3); 
$filj = substr(fill, -4);
$tmpName = $_FILES['userfile'] ['tmp_name'];
$imagearray = getimagesize($tmpName);

echo "mime $imagearray[mime] <br>";
$valid_types = array(IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG);

echo "file $fill sub $fil";







if (in_array($imagearray[2],  $valid_types)) { 

echo $_FILES['userfile'] ['tmp_name'];
$fileName = $_FILES['userfile'] ['name'];
$tmpName = $_FILES['userfile'] ['tmp_name'];
$fileSize = $_FILES['userfile'] ['size'];
echo "size $fileSize<br>";
$fp = fopen($tmpName, 'r');
$content = fread($fp, $fileSize);
$content = addslashes($content);
fclose($fp);
$picture = str_replace(' ', '_', $tmpName);

$source = $picture;
$nax = str_replace(' ', '-', $subtitle);
$na = $nax . '-' . $titleid . '-' . $newid;
$target = '../../sew/' . $fileName;
$newname = '../../sew/' . $na . '.jpg';
$newna = 'sew/' . $na . '.jpg';
move_uploaded_file($source, $newname );
$newname = 'sew/' . $na . '.jpg';

$image = $newname;
echo "File<b> $fileName $picture picture</b> uploaded as id= $id<br>";
echo "File<b> $fileName</b> uploaded<br>"; 
echo "<b>All images in pic directory gallery</b></br >"; } else { 
echo "the type of file is not acceptable, go back and try again";  } 



echo "File<b> $fileName</b> uploaded<br>";
echo "<b>All images in pic directory gallery</b></br >"; 
$sq = $db->query("UPDATE bodblog SET titleid = '$titleid', subtitle = '$subtitle', txt = '$txt', equip = '$equip', details = '$details', img1 = '$image' WHERE bbl_id = '$newid'");

